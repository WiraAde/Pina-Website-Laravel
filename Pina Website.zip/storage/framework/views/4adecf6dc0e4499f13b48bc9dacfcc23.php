

<?php $__env->startSection('content'); ?>
    <?php
        $title = 'List data - Admin';
    ?>

    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-1 align-items-center">
                <div class="col-auto ms-auto d-print-none">
                    <div class="btn-list">
                        <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-primary d-none d-sm-inline">
                            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <path d="M12 5l0 14"></path>
                                <path d="M5 12l14 0"></path>
                            </svg>
                            Tambahkan Website
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="container-xl">

            <div class="row row-cards">
                <div class="col-lg-13">
                    <div class="card">
                        <div class="table-responsive">
                            <table class="table table-vcenter card-table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Jenis Website</th>
                                        <th>Keterangan</th>
                                        <th>Harga</th>
                                        <th colspan="2"></th>
                                    </tr>
                                </thead>
                                <?php
                                    $no = 1;
                                ?>
                                <tbody>
                                    <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($listing->title); ?></td>
                                            <td class="text-muted"><?php echo e($listing->company); ?></td>
                                            <td class="text-muted">Rp.<?php echo e($listing->location); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.edit', $listing->id)); ?>">Edit</a>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.hapus', $listing->id)); ?>"
                                                    onclick="return confirm('Apakah Anda Ingin Mehapus Data ini?');">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.default_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan2\resources\views/admin/list.blade.php ENDPATH**/ ?>
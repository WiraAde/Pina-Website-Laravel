<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>


    <link href="<?php echo e(asset('css/sb-admin-2.min.css')); ?>" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Selamat Datang!</h1>
                                    </div>
                                    <form class="user" action="<?php echo e(route('login.proses-login')); ?>" method="POST"
                                        id="logForm">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <?php $__errorArgs = ['login_gagal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                
                                                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                                    
                                                    <span class="alert-inner--text"><strong>Warning!</strong>
                                                        <?php echo e($message); ?></span>
                                                    <button type="button" class="close" data-dismiss="alert"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <input class="form-control form-control-user" id="username" name="username"
                                                type="text" placeholder="Masukkan Username" />
                                            <?php if($errors->has('username')): ?>
                                                <span><?php echo e($errors->first('username')); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user" id="password"
                                                name="password" placeholder="Masukkan Password">
                                            <?php if($errors->has('password')): ?>
                                                <span><?php echo e($errors->first('password')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <button type="submit" class="btn btn-primary btn-user btn-block">Login</button>


                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="<?php echo e(route('forgot.form-forgot')); ?>">Lupa Password?</a>
                                    </div>
                                    <div class="text-center">
                                        <a class="small" href="<?php echo e(route('register.form-register')); ?>">Buat Akun
                                            Anda!</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\latihan2\resources\views/pengguna/form_login.blade.php ENDPATH**/ ?>
<footer class="footer footer-transparent d-print-none">
    <div class="container-xl">
        <div class="row text-center align-items-center flex-row-reverse">
            <div class="col-lg-auto ms-lg-auto">

            </div>
            <div>
                <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item">
                        Copyright &copy; 2023
                        <a href="." class="link-secondary">Pina Website</a>.
                        All rights reserved.
                    </li>

                </ul>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\latihan2\resources\views/templates/partials_user/footer.blade.php ENDPATH**/ ?>
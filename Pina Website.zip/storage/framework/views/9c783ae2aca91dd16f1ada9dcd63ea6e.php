 <!-- Libs JS -->
 <script src="<?php echo e(asset('./dist/libs/apexcharts/dist/apexcharts.min.js?1684106062')); ?>" defer></script>
 <script src="<?php echo e(asset('./dist/libs/jsvectormap/dist/js/jsvectormap.min.js?1684106062')); ?>" defer></script>
 <script src="<?php echo e(asset('./dist/libs/jsvectormap/dist/maps/world.js?1684106062')); ?>" defer></script>
 <script src="<?php echo e(asset('./dist/libs/jsvectormap/dist/maps/world-merc.js?1684106062')); ?>" defer></script>
 <!-- Tabler Core -->
 <script src="<?php echo e(asset('./dist/js/tabler.min.js?1684106062')); ?>" defer></script>
 <script src="<?php echo e(asset('./dist/js/demo.min.js?1684106062')); ?>" defer></script>
 <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<?php /**PATH C:\xampp\htdocs\latihan2\resources\views/templates/script.blade.php ENDPATH**/ ?>